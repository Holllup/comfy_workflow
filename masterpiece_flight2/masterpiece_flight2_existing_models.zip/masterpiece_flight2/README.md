# 名画空间飞行 · ComfyUI 工作流

六份可拖入 ComfyUI 的工作流，分成两条路径：

1. **AutoDL 已有模型快速路径**：`workflows/01_keyframes_nunchaku.json` → `workflows/02_pilot_wan5b.json` → `workflows/03_full_wan5b.json`。使用预装的 Nunchaku Qwen-Image-Edit-2509 和 Wan 2.2 5B，不必下载 Qwen FP8 或 LTX-2.5 权重。Wan 5B 只能约束首帧；工作流在各段最后 8 帧平滑接入已选关键帧，保证首尾图像准确，但镜头连续性需要人工检查。
2. **首尾帧模型路径**：`workflows/01_keyframes.json` → `workflows/02_pilot_5s.json` → `workflows/03_full_20s.json`。使用官方 Qwen FP8 与 LTX-2.5 首尾帧模板，需要另行下载模型。

使用顺序、所需模型、显卡测试及输出位置见 [中文安装说明](README_%E5%AE%89%E8%A3%85.md)。ChatGPT 编剧提示词在 [PROMPT_ChatGPT编剧.md](PROMPT_ChatGPT%E7%BC%96%E5%89%A7.md)；示例分镜在 `examples/starry_night_story.json`。

首版支持有可进入空间的风景、城市、建筑和室内场景画。作品识别和史料核对由 ChatGPT 完成，你审稿后再粘贴 JSON；ComfyUI 不调用 OpenAI API。完整原画保存在项目目录的 `source.png`，横屏尾帧保存在 `ending.png`，尾帧没有经过 AI 重画。成片 MP4 编码会造成正常的像素压缩。

本地检查：从工作区根目录运行 `python3 -m unittest discover -s masterpiece_flight2/tests -q`。本地没有 NVIDIA GPU 或 AutoDL 连接时，这些检查不代表已完成模型推理。
