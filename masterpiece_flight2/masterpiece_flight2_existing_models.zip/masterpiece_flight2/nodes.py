"""Small ComfyUI nodes for reviewed painting-flight projects."""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path

import numpy as np

from . import core


def _root() -> Path:
    override = os.environ.get("ART_PROJECT_ROOT")
    if override:
        return Path(override)
    import folder_paths
    return Path(folder_paths.get_output_directory()) / "masterpiece_flight2"


def _numpy_image(image) -> np.ndarray:
    if hasattr(image, "detach"):
        array = image.detach().cpu().numpy()
    else:
        array = np.asarray(image)
    if array.ndim == 4:
        if array.shape[0] != 1:
            raise ValueError("Expected exactly one image")
        array = array[0]
    return core._rgb_uint8(array)


def _tensor_image(image: np.ndarray):
    batch = np.asarray(image, dtype=np.float32)[None] / 255.0
    try:
        import torch
    except ModuleNotFoundError:
        return batch
    return torch.from_numpy(batch.copy())


class ArtPrepare:
    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {
            "painting": ("IMAGE",),
            "project_id": ("STRING", {"default": "starry_night"}),
            "story_json": ("STRING", {"default": "", "multiline": True}),
        }}

    RETURN_TYPES = ("IMAGE", "STRING", "STRING")
    RETURN_NAMES = ("canvas", "story_json", "project_id")
    FUNCTION = "run"
    CATEGORY = "masterpiece_flight2"

    def run(self, painting, project_id, story_json):
        project = core.init_project(_root(), project_id, story_json, _numpy_image(painting))
        normalized = json.dumps(project["story"], ensure_ascii=False)
        return (_tensor_image(project["ending"]), normalized, project_id)


class ArtFrameText:
    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {
            "story_json": ("STRING", {"forceInput": True}),
            "index": ("INT", {"default": 4, "min": 1, "max": 4}),
            "seed_base": ("INT", {"default": 487201, "min": 0, "max": 2147483000}),
        }}

    RETURN_TYPES = ("STRING", "INT")
    RETURN_NAMES = ("image_prompt", "seed")
    FUNCTION = "run"
    CATEGORY = "masterpiece_flight2"

    def run(self, story_json, index, seed_base):
        plan = core.validate_story(story_json)
        if index not in (1, 2, 3, 4):
            raise ValueError("Frame index must be 1–4")
        return (plan["keyframes"][index - 1]["image_prompt_en"], seed_base + index)


class ArtSaveKeyframe:
    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {
            "image": ("IMAGE",),
            "project_id": ("STRING", {"forceInput": True}),
            "index": ("INT", {"default": 4, "min": 1, "max": 4}),
        }}

    RETURN_TYPES = ("IMAGE", "STRING")
    RETURN_NAMES = ("image", "draft_path")
    FUNCTION = "run"
    CATEGORY = "masterpiece_flight2"
    OUTPUT_NODE = True

    def run(self, image, project_id, index):
        path = core.save_keyframe(_root(), project_id, index, _numpy_image(image))
        return (image, str(path))


class ArtLoadApproved:
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {"project_id": ("STRING", {"default": "starry_night"})},
            "optional": {"render_model": ("STRING", {"default": "LTX-2.5 distilled Comfy int8"})},
        }

    RETURN_TYPES = ("IMAGE", "IMAGE", "IMAGE", "IMAGE", "IMAGE", "STRING", "STRING")
    RETURN_NAMES = ("frame_01", "frame_02", "frame_03", "frame_04", "ending", "story_json", "project_id")
    FUNCTION = "run"
    CATEGORY = "masterpiece_flight2"

    @classmethod
    def IS_CHANGED(cls, project_id, render_model="LTX-2.5 distilled Comfy int8"):
        project = core._project_path(_root(), project_id)
        paths = [project / "story.json", project / "ending.png"] + [
            project / "approved" / f"frame_{i:02d}.png" for i in range(1, 5)
        ]
        digest = hashlib.sha256()
        digest.update(render_model.encode())
        for path in paths:
            digest.update(path.name.encode())
            digest.update(path.read_bytes() if path.exists() else b"missing")
        return digest.hexdigest()

    def run(self, project_id, render_model="LTX-2.5 distilled Comfy int8"):
        project = core.load_project(_root(), project_id)
        story_json = json.dumps(project["story"], ensure_ascii=False)
        settings = {
            "project_id": project_id,
            "frame_sha256": {
                f"frame_{i:02d}": hashlib.sha256((project["path"] / "approved" / f"frame_{i:02d}.png").read_bytes()).hexdigest()
                for i in range(1, 5)
            },
            "video_model": render_model,
            "duration_seconds_per_shot": 5,
            "width": 1280,
            "height": 720,
            "fps": 24,
            "video_seeds": [932100 + i * 101 for i in range(1, 5)],
            "audio": False,
        }
        if render_model == "Wan2.2 5B TI2V":
            settings["latent_height"] = 704
            settings["bridge_frames"] = 8
        (project["path"] / "render_settings.json").write_text(
            json.dumps(settings, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
        )
        manifest_path = project["path"] / "manifest.json"
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        manifest["status"] = "approved_loaded"
        manifest["approved_frame_sha256"] = settings["frame_sha256"]
        manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        return tuple(_tensor_image(frame) for frame in project["frames"]) + (
            _tensor_image(project["ending"]), story_json, project_id
        )


class ArtMotionText:
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "story_json": ("STRING", {"forceInput": True}),
                "index": ("INT", {"default": 1, "min": 1, "max": 4}),
            },
            "optional": {"prior_video": ("VIDEO",), "prior_images": ("IMAGE",)},
        }

    RETURN_TYPES = ("STRING",)
    RETURN_NAMES = ("motion_prompt",)
    FUNCTION = "run"
    CATEGORY = "masterpiece_flight2"

    def run(self, story_json, index, prior_video=None, prior_images=None):
        plan = core.validate_story(story_json)
        if index not in (1, 2, 3, 4):
            raise ValueError("Shot index must be 1–4")
        return (plan["shots"][index - 1]["motion_prompt_en"],)


class ArtHoldFrames:
    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {
            "image": ("IMAGE",),
            "count": ("INT", {"default": 24, "min": 1, "max": 240}),
        }}

    RETURN_TYPES = ("IMAGE",)
    RETURN_NAMES = ("images",)
    FUNCTION = "run"
    CATEGORY = "masterpiece_flight2"

    def run(self, image, count):
        if image.shape[0] != 1:
            raise ValueError("Hold expects one original image")
        if hasattr(image, "detach"):
            return (image.repeat((count, 1, 1, 1)),)
        return (np.repeat(np.asarray(image), count, axis=0),)


class ArtBridgeFrames:
    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {
            "images": ("IMAGE",),
            "start": ("IMAGE",),
            "target": ("IMAGE",),
            "blend_frames": ("INT", {"default": 8, "min": 1, "max": 24}),
        }}

    RETURN_TYPES = ("IMAGE",)
    RETURN_NAMES = ("images",)
    FUNCTION = "run"
    CATEGORY = "masterpiece_flight2"

    def run(self, images, start, target, blend_frames):
        data = images.detach().cpu().numpy() if hasattr(images, "detach") else np.asarray(images)
        result = core.bridge_video_frames(data, _numpy_image(start), _numpy_image(target), blend_frames)
        batch = result.astype(np.float32) / 255.0
        try:
            import torch
        except ModuleNotFoundError:
            return (batch,)
        return (torch.from_numpy(batch),)


class ArtJoinFrames:
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {"clip1": ("IMAGE",), "still": ("IMAGE",)},
            "optional": {"clip2": ("IMAGE",), "clip3": ("IMAGE",), "clip4": ("IMAGE",)},
        }

    RETURN_TYPES = ("IMAGE",)
    RETURN_NAMES = ("images",)
    FUNCTION = "run"
    CATEGORY = "masterpiece_flight2"

    def run(self, clip1, still, clip2=None, clip3=None, clip4=None):
        segments = [clip for clip in (clip1, clip2, clip3, clip4) if clip is not None] + [still]
        shape = tuple(clip1.shape[1:])
        if any(tuple(segment.shape[1:]) != shape for segment in segments):
            raise ValueError("All video segments must share one resolution")
        if hasattr(clip1, "detach"):
            import torch
            return (torch.cat(segments, dim=0),)
        return (np.concatenate(segments, axis=0),)


class ArtOutputPrefix:
    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {
            "project_id": ("STRING", {"forceInput": True}),
            "label": ("STRING", {"default": "final"}),
        }}

    RETURN_TYPES = ("STRING",)
    RETURN_NAMES = ("prefix",)
    FUNCTION = "run"
    CATEGORY = "masterpiece_flight2"

    def run(self, project_id, label):
        core._project_path(_root(), project_id)
        if label not in {
            "pilot", "final", "shot_01", "shot_02", "shot_03", "shot_04",
            "wan_pilot", "wan_final", "wan_shot_01", "wan_shot_02", "wan_shot_03", "wan_shot_04",
        }:
            raise ValueError("Unknown output label")
        return (f"masterpiece_flight2/{project_id}/{label}",)


NODE_CLASS_MAPPINGS = {
    "ArtPrepare": ArtPrepare,
    "ArtFrameText": ArtFrameText,
    "ArtSaveKeyframe": ArtSaveKeyframe,
    "ArtLoadApproved": ArtLoadApproved,
    "ArtMotionText": ArtMotionText,
    "ArtHoldFrames": ArtHoldFrames,
    "ArtBridgeFrames": ArtBridgeFrames,
    "ArtJoinFrames": ArtJoinFrames,
    "ArtOutputPrefix": ArtOutputPrefix,
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "ArtPrepare": "名画飞行 · 创建项目",
    "ArtFrameText": "名画飞行 · 关键帧提示词",
    "ArtSaveKeyframe": "名画飞行 · 保存关键帧",
    "ArtLoadApproved": "名画飞行 · 读取选定关键帧",
    "ArtMotionText": "名画飞行 · 飞行提示词",
    "ArtHoldFrames": "名画飞行 · 原画定格",
    "ArtBridgeFrames": "名画飞行 · Wan 关键帧衔接",
    "ArtJoinFrames": "名画飞行 · 拼接帧序列",
    "ArtOutputPrefix": "名画飞行 · 输出路径",
}
